import { TdFabProps } from './type';
declare const props: TdFabProps;
export default props;
