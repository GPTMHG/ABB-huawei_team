import { TdPickerProps } from './type';
declare const props: TdPickerProps;
export default props;
