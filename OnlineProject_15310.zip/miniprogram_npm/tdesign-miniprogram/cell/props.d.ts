import { TdCellProps } from './type';
declare const props: TdCellProps;
export default props;
