const props = {
    text: {
        type: String,
        value: '',
    },
    logo: {
        type: Object,
    },
    links: {
        type: Array,
        value: [],
    },
};
export default props;
